import './maindashboard.css';
import React from 'react';

async function MainDashboard () {
        console.log("1");
        const url = 'https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT';
        const response = await fetch (url);
        console.log("5");
        const data = await response.json();
        console.log("2");
        console.log(data.price);
        console.log("3");

  return (
      <div className="main-chart">
          Chart here
      </div>
  );
}
export default MainDashboard;





    