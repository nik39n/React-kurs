import './mainchart.css';
function MainChart () {
    return (
        <div className="main-chart">
            Chart here
        </div>
    );
}

export default MainChart;